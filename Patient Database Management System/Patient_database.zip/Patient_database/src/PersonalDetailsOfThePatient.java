
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DELL
 */
public class PersonalDetailsOfThePatient extends javax.swing.JFrame {

    /**
     * Creates new form PersonalDetailsOfThePatient
     */
    public PersonalDetailsOfThePatient() {
        initComponents();
    }
        
    public PersonalDetailsOfThePatient(String para) {
        initComponents();
        tfAadhar.setText(para); 
        display();
    }
    
        public void close(){
        WindowEvent winClosingEvent;
        winClosingEvent = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClosingEvent);
    }
        
        
        public void display(){
             String Aadhar=tfAadhar.getText(); 
      //new PatientDetails(msg) =
       Connection conn = null;//create object of Connection and define it null

      try //try block
      {
      //STEP 2: Register JDBC driver
      Class.forName("oracle.jdbc.OracleDriver");
      //STEP 3: Open a connection
      System.out.println("Connecting to a selected database...");
      conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "patient_database", "patient1234");
                        //print on console
                        if(conn!=null)
      System.out.println("Connected database successfully...");    
                        else
      System.out.println("NOT Connected");                       
     
         Statement stmt4 = null;
         Statement myStmt4;
         myStmt4 = conn.createStatement();
         ResultSet myRs4;
         myRs4 = myStmt4.executeQuery("select * from patient where aadhar_no='"+Aadhar+"'");
         System.out.println("Executed");         

        while(myRs4.next()){
         //   System.out.println(myRs4.getString("first_name"));
         if(myRs4.getString("middle_name").equals(""))
           tfFullName.setText("Name : "+myRs4.getString("first_name")+" "+" ."+myRs4.getString("last_name"));
         else
            tfFullName.setText("Name : "+myRs4.getString("first_name")+" "+myRs4.getString("middle_name")+" ."+myRs4.getString("last_name")); 
           String dob=myRs4.getString("dob");
           String DOB=dob.substring(0,10);
           lDOB.setText("Date of birth : "+DOB);
           lAddress.setText("Address : "+myRs4.getString("address")+" ,"+myRs4.getString("pin_code"));
           lContact.setText("Contact Number : "+myRs4.getString("p_contactno"));
           
           
           
         Statement stmt2 = null;
         Statement myStmt2;
         myStmt2 = conn.createStatement();
         ResultSet myRs2;
         myRs2 = myStmt2.executeQuery("select * from emergency_contact where aadhar_no='"+Aadhar+"'");
         while(myRs2.next()){
           System.out.println(myRs2.getString("name"));
           lECName.setText("Name : "+myRs2.getString("name"));
           lECRelationship.setText("Relationship : "+myRs2.getString("Relationship"));
           lECAddress.setText("Address : "+myRs2.getString("ADRRESS"));
           lECContact.setText("Contact Number : "+myRs2.getString("CONTACT_NO"));           
         }
         
         Statement stmt3 = null;
         Statement myStmt3;
         myStmt3 = conn.createStatement();
         ResultSet myRs3;
         myRs3 = myStmt3.executeQuery("select * from disability where aadhar_no='"+Aadhar+"'");
        
         while(myRs3.next()){
           lDisability.setText("Disability : "+myRs3.getString("DISABILITY_NAME"));         
         }
         
         Statement stmt5 = null;
         Statement myStmt5;
         myStmt5 = conn.createStatement();
         ResultSet myRs5;
         myRs5 = myStmt5.executeQuery("select * from allergy where aadhar_no='"+Aadhar+"'");
        
         while(myRs5.next()){
           lDisability.setText("Allergy : "+myRs5.getString("SUBSTANCE_NAME"));         
         }
        DefaultTableModel model = (DefaultTableModel) tjScheme.getModel();
         Statement stmt6 = null;
         Statement myStmt6;
         myStmt6 = conn.createStatement();
         ResultSet myRs6;
         myRs6 = myStmt6.executeQuery("select * from scheme_eligible where aadhar_no='"+Aadhar+"'");
        
         while(myRs6.next()){
           String sid=myRs6.getString("SCHEME_ID");  
         Statement stmt = null;
         Statement myStmt8;
         myStmt8 = conn.createStatement();
         ResultSet myRs8;
         myRs8 = myStmt8.executeQuery("select * from scheme where SCHEME_ID='"+sid+"'");
           Vector row1 = new Vector();
            while(myRs8.next()) {
                String scheme=myRs8.getString("sname");
                row1.add(scheme);
                model.addRow(row1);
            }
         }

           
       
       }
                
      }
      
      catch(SQLException se) //catch block
      {
      //Handle errors for JDBC
      se.printStackTrace();
      }
      catch(Exception e) //catch block
      {
      //Handle errors for Class.forName
      e.printStackTrace();
      }
      finally  //finally block
      {
      //finally block used to close resources
      try  //try block
      {
      if(conn!=null)//condition
      conn.close(); //close connection
      }
      catch(SQLException se)//Handle errors
      {
      se.printStackTrace();
      }//end finally try
      }//end try
      
      System.out.println("End");
      

    }                                        


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        tfAadhar = new javax.swing.JLabel();
        tfName = new javax.swing.JLabel();
        tfFullName = new javax.swing.JLabel();
        lDOB = new javax.swing.JLabel();
        lAddress = new javax.swing.JLabel();
        lContact = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lECName = new javax.swing.JLabel();
        lECRelationship = new javax.swing.JLabel();
        lECAddress = new javax.swing.JLabel();
        lECContact = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lDisability = new javax.swing.JLabel();
        lAllergy = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tjScheme = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        jPasswordField1.setText("jPasswordField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 0));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Personal Information");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(380, 20, 390, 70);

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\icons\\back.PNG")); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(970, 780, 120, 40);

        tfAadhar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(tfAadhar);
        tfAadhar.setBounds(120, 80, 320, 40);

        tfName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(tfName);
        tfName.setBounds(691, 145, 279, 32);

        tfFullName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(tfFullName);
        tfFullName.setBounds(31, 145, 420, 37);

        lDOB.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(lDOB);
        lDOB.setBounds(31, 189, 301, 46);

        lAddress.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lAddress.setToolTipText("");
        jPanel1.add(lAddress);
        lAddress.setBounds(31, 242, 939, 36);

        lContact.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(lContact);
        lContact.setBounds(31, 285, 321, 43);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Emergency Contact");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(31, 335, 176, 22);

        lECName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(lECName);
        lECName.setBounds(31, 364, 347, 31);

        lECRelationship.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(lECRelationship);
        lECRelationship.setBounds(31, 402, 330, 34);

        lECAddress.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(lECAddress);
        lECAddress.setBounds(31, 443, 458, 34);

        lECContact.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(lECContact);
        lECContact.setBounds(31, 490, 309, 39);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Medical Conditions:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(31, 538, 202, 43);

        lDisability.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(lDisability);
        lDisability.setBounds(31, 588, 381, 33);

        lAllergy.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(lAllergy);
        lAllergy.setBounds(31, 628, 381, 32);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("Schemes (if any) :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(70, 670, 196, 37);

        tjScheme.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tjScheme.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Schemes :"
            }
        ));
        jScrollPane2.setViewportView(tjScheme);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(80, 710, 474, 135);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("Aadhar No:");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(10, 80, 140, 50);

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\DELL\\Desktop\\icons\\background3.v4.PNG")); // NOI18N
        jPanel1.add(jLabel7);
        jLabel7.setBounds(0, 0, 1880, 900);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 2000, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1081, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String Aadhar= tfAadhar.getText();
      PatientDetails details=new PatientDetails(Aadhar);
      details.setVisible(true);
      close();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PersonalDetailsOfThePatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PersonalDetailsOfThePatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PersonalDetailsOfThePatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PersonalDetailsOfThePatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
     PersonalDetailsOfThePatient myf=new PersonalDetailsOfThePatient();
     myf.setState(Frame.NORMAL);
     myf.setVisible(true); 
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
             //   new PersonalDetailsOfThePatient().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lAddress;
    private javax.swing.JLabel lAllergy;
    private javax.swing.JLabel lContact;
    private javax.swing.JLabel lDOB;
    private javax.swing.JLabel lDisability;
    private javax.swing.JLabel lECAddress;
    private javax.swing.JLabel lECContact;
    private javax.swing.JLabel lECName;
    private javax.swing.JLabel lECRelationship;
    private javax.swing.JLabel tfAadhar;
    private javax.swing.JLabel tfFullName;
    private javax.swing.JLabel tfName;
    private javax.swing.JTable tjScheme;
    // End of variables declaration//GEN-END:variables
}
