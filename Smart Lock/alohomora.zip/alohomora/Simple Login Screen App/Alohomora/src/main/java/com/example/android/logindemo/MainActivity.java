package com.example.android.logindemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.w3c.dom.Text;
import android.view.View;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import android.view.View.OnClickListener;
import android.widget.Toast;
import static android.content.ContentValues.TAG;

public class MainActivity extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter = 5;
    private Button NewUser;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // super.onCreate(savedInstanceState);

        Name = (EditText)findViewById(R.id.etName);
        Password = (EditText)findViewById(R.id.etPassword);
        Info = (TextView)findViewById(R.id.tvInfo);
        Login = (Button)findViewById(R.id.btnLogin);
        NewUser=(Button)findViewById(R.id.btnnewuser);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email_id=Name.getText().toString();
                String password=Password.getText().toString();
                Toast.makeText(MainActivity.this, "sending", Toast.LENGTH_SHORT).show();

                if(!email_id.isEmpty() && !password.isEmpty())
                {
                    new MyTask5().execute(email_id,password);

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "UserName or Password cannot be blank", Toast.LENGTH_SHORT).show();

                }

            }
        });
        NewUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent=new Intent(getApplicationContext(),Registration.class);
                startActivity(intent);
            }
        });




    }

    class MyTask5 extends AsyncTask<String, Void, JSONObject> {

        protected JSONObject doInBackground(String... params) {


            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;

            //Toast.makeText(MainActivity.this, "task 5", Toast.LENGTH_SHORT).show();
            //String yoururl = "18.220.251.80/testdb2.php";
            String yoururl ="18.188.117.229/UserLogin.php";

            String email_id = params[0];
            String password = params[1];

            try {

                String url = "http://" + yoururl;
                ArrayList<NameValuePair> valuePairs = new ArrayList<NameValuePair>();
                valuePairs.add(new BasicNameValuePair("email_id", email_id));
                valuePairs.add(new BasicNameValuePair("password", password));
                Log.e("Username - ",email_id);
                Log.e("Password - ",password);
                DefaultHttpClient httpClient = new DefaultHttpClient();
                String paramString = URLEncodedUtils.format(valuePairs, "utf-8");
                url += "?"+paramString;
                Log.e("url - ",url);
                HttpGet httpGet = new HttpGet(url);

                //Toast.makeText(MainActivity.this, "task 5", Toast.LENGTH_SHORT).show();

                HttpResponse httpResponse = httpClient.execute(httpGet);

                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e(TAG, "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 100);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");

                }
                is.close();
                json = sb.toString();
                Log.e(TAG, json);
                jObj = new JSONObject(json);
                jObj.put("error_code", error);

                Log.e("Action", "Success");

            } catch (Exception e) {
                Log.e(TAG, "Error result " + e.toString());
            }

            return jObj;


        }
        @Override
        protected void onPostExecute(JSONObject result) {
//            progressBar.setVisibility(View.INVISIBLE);
//            btn.setVisibility(View.VISIBLE);
            try {
                //List<String&gt; userNames = new ArrayList&lt;&gt;();
                //JSONArray array = new JSONArray(result);
                if (result != null) {
                    Log.e(TAG, "Result " + result);
                    if (!result.isNull("message")) {
                        String message = result.getString("message");
                        if (message.equals("success")) {
                            Toast.makeText(getApplicationContext(), "Valid User", Toast.LENGTH_SHORT).show();
                            Intent intent=new Intent(getApplicationContext(),SecondActivity.class);
                            startActivity(intent);
                        }  else if (message.equals("fail")) {
                            Toast.makeText(getApplicationContext(), "Invalid User", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Failed ", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Unable to retrieve any data from server");
                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Failed to send data", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Exception=" + Log.getStackTraceString(e));
            }
        }
    }
}
