package com.example.android.logindemo;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.jar.Attributes;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static android.content.ContentValues.TAG;

public class Registration extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        final EditText Name, Age, Address, EmailID, Password, MobileNumber;
        Button Back;
        Button Register;

        Name = (EditText) findViewById(R.id.etName);
        Age = (EditText) findViewById(R.id.etAge);
        Address = (EditText) findViewById(R.id.etAddress);
        EmailID = (EditText) findViewById(R.id.etEmailId);
        Password = (EditText) findViewById(R.id.etPassword);
        MobileNumber = (EditText) findViewById(R.id.etMobileNumber);

        Back = (Button) findViewById(R.id.btBack);
        Register = (Button) findViewById(R.id.btRegister);
        //}
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = Name.getText().toString();
                String age = Age.getText().toString();
                String address = Address.getText().toString();
                String email_id = EmailID.getText().toString();
                String password = Password.getText().toString();
                String mobile = MobileNumber.getText().toString();
                String bluetooth_id= "B01";
                if (!name.isEmpty() && !age.isEmpty() && !address.isEmpty()&&!email_id.isEmpty()
                        && !mobile.isEmpty() && !password.isEmpty()) {

                    new MyTask3().execute(email_id,name,age, password,bluetooth_id, mobile,address);
                    // new MyTask3.execute(userName, passWord, rPassword, mobile);
                } else {
                    Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_LONG).show();
                }
            }
        });

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });
    }
//}


    class MyTask3 extends AsyncTask<String, Void, JSONObject> {

        protected JSONObject doInBackground(String... params) {


            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;

            //String yoururl = "18.220.251.80/testdb2.php";
            //String yoururl = "18.217.196.192/test2.php";

            String yoururl = "18.188.117.229/myregister.php";

            String email_id = params[0];
            String name = params[1];
            String age = params[2];
            String password = params[3];
            String bluetooth_id= params[4];
            String mobile = params[5];
            String address = params[6];


            try {

                String url = "http://" + yoururl;
                ArrayList<NameValuePair> valuePairs = new ArrayList<NameValuePair>();
                valuePairs.add(new BasicNameValuePair("email_id", email_id));
                valuePairs.add(new BasicNameValuePair("name", name));
                valuePairs.add(new BasicNameValuePair("age", age));
                valuePairs.add(new BasicNameValuePair("password", password));
                valuePairs.add(new BasicNameValuePair("bluetooth_id", bluetooth_id));
                valuePairs.add(new BasicNameValuePair("mobile", mobile));
                valuePairs.add(new BasicNameValuePair("address", address));
                DefaultHttpClient httpClient = new DefaultHttpClient();
                String paramString = URLEncodedUtils.format(valuePairs, "utf-8");
                url += "?" + paramString;
                HttpGet httpGet = new HttpGet(url);

                HttpResponse httpResponse = httpClient.execute(httpGet);
                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e(TAG, "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 100);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                Log.e(TAG, json);
                jObj = new JSONObject(json);
                jObj.put("error_code", error);

                Toast.makeText(getApplicationContext(), "Register Success", Toast.LENGTH_SHORT).show();

                Log.e("Action", "Success");


            } catch (Exception e) {
                Log.e(TAG, "Error result " + e.toString());
            }


            return jObj;


        }

        @Override
        protected void onPostExecute(JSONObject result) {
//            progressBar.setVisibility(View.INVISIBLE);
//            btn.setVisibility(View.VISIBLE);
            try {
                if (result != null) {
                    Log.e(TAG, "Result " + result);
                    if (!result.isNull("message")) {
                        String message = result.getString("message");
                        if (message.equals("success")) {
                            Toast.makeText(getApplicationContext(), "Register Success", Toast.LENGTH_SHORT).show();
                        }  else if (message.equals("fail")) {
                            Toast.makeText(getApplicationContext(), "Oops! There was an error registering you.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Failed ", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Unable to retrieve any data from server");
                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Failed to send data", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Exception=" + Log.getStackTraceString(e));
            }
        }

    }

}
