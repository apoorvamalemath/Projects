package com.example.abhishek.sihproject;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.abhishek.sihproject.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static android.text.TextUtils.isEmpty;

public class Login extends AppCompatActivity {

    EditText username;
    EditText password;

    Button login;
    Button register;

    String strEmail, strPassword;

    private static final String TAG = "LoginActivity";
    private FirebaseAuth.AuthStateListener mAuthListener;

    ProgressDialog progress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_new_login);

        username = (EditText)findViewById(R.id.editText);
        password = (EditText)findViewById(R.id.editTex2);

        login = (Button)findViewById(R.id.button);
        register = (Button)findViewById(R.id.button2);

        progress = new ProgressDialog(this);
        progress.setTitle("Loading");
        progress.setMessage("Verifying details...");
        progress.setCancelable(false);
        progress.setCanceledOnTouchOutside(true);

        progress.setOnCancelListener(new DialogInterface.OnCancelListener(){
            @Override
            public void onCancel(DialogInterface dialog){
                /****cleanup code****/

                progress.dismiss();
            }});

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                progress.show();

                strEmail = username.getText().toString();
                strPassword = password.getText().toString();

                //signIn();

                new LoginAsyncTask().execute(strEmail,strPassword);


            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progress.show();
                Intent i = new Intent(getApplicationContext(), SignUp.class);

                startActivity(i);
            }
        });

        setupFirebaseAuth();
        hideSoftKeyboard();

    }

    class LoginAsyncTask extends AsyncTask<String, Void, JSONObject> {

        protected JSONObject doInBackground(String... params) {


            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;

            String yoururl = "3.94.184.247/signin.php";

            String mobile = params[0];
            String password=params[1];

            try {

                String url = "http://" + yoururl;
                ArrayList<NameValuePair> valuePairs = new ArrayList<NameValuePair>();

                valuePairs.add(new BasicNameValuePair("emailid", mobile));
                valuePairs.add(new BasicNameValuePair("password", password));

                DefaultHttpClient httpClient = new DefaultHttpClient();

                String paramString = URLEncodedUtils.format(valuePairs, "utf-8");
                url += "?"+paramString;

                HttpGet httpGet = new HttpGet(url);

                HttpResponse httpResponse = httpClient.execute(httpGet);

                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e("Response", "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 100);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                Log.e("json", json);
                jObj = new JSONObject(json);
                jObj.put("error_code", error);

                Log.e("Action", "Success");



            } catch (Exception e) {
                //Log.e(TAG, "Error result " + e.toString());
            }

            return jObj;


        }
        @Override
        protected void onPostExecute(JSONObject result) {
            try {
                if (result != null) {
                    Log.e("Result", "Result " + result);
                    if (!result.isNull("message")) {
                        String message = result.getString("message");
                        if (message.equals("success")) {

                            Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();

                            Intent intent=new Intent(getApplicationContext(),Hoomescreen.class);

                            intent.putExtra("email",strEmail);

                            startActivity(intent);
                        }  else if (message.equals("fail")) {
                            Toast.makeText(getApplicationContext(), "Invalid User", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Failed ", Toast.LENGTH_SHORT).show();
                    Log.e("Unable", "Unable to retrieve any data from server");
                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Failed to send data", Toast.LENGTH_SHORT).show();
                Log.e("Exception", "Exception=" + Log.getStackTraceString(e));
            }
        }
    }

    private void setupFirebaseAuth(){
        Log.d(TAG, "setupFirebaseAuth: started.");

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
                    Toast.makeText(getApplicationContext(), "Authenticated with: " + user.getEmail(), Toast.LENGTH_SHORT).show();

                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                            .setTimestampsInSnapshotsEnabled(true)
                            .build();
                    db.setFirestoreSettings(settings);

                    DocumentReference userRef = db.collection(getString(R.string.collection_users))
                            .document(user.getUid());

                    userRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if(task.isSuccessful()){
                                Log.d(TAG, "onComplete: successfully set the user client.");
                                User user = task.getResult().toObject(User.class);

                                //((UserClient)(getApplicationContext())).setUser(user);

                            }
                        }
                    });

                    Intent intent = new Intent(getApplicationContext(), Hoomescreen.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();

                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                }
                // ...
            }
        };
    }

    private void hideSoftKeyboard(){
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    private void signIn(){
        //check if the fields are filled out
        if(!isEmpty(strEmail)
                && !isEmpty(strPassword))
        {
            Log.d(TAG, "onClick: attempting to authenticate.");

            progress.show();

            FirebaseAuth.getInstance().signInWithEmailAndPassword(strEmail,strPassword)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            progress.dismiss();

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getApplicationContext(), "Authentication Failed", Toast.LENGTH_SHORT).show();

                    progress.dismiss();
                }
            });
        }
        else
            {
            Toast.makeText(getApplicationContext(), "You didn't fill in all the fields.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);
        }
    }


}
