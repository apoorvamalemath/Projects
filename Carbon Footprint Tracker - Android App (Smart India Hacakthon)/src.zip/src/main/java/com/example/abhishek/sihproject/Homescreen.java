package com.example.abhishek.sihproject;

import android.app.PendingIntent;
import android.content.ClipData;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.location.ActivityRecognition;
import com.google.android.gms.location.ActivityTransition;
import com.google.android.gms.location.ActivityTransitionEvent;
import com.google.android.gms.location.ActivityTransitionRequest;
import com.google.android.gms.location.ActivityTransitionResult;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.ArrayList;
import java.util.List;

public class Homescreen extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreen);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setHomeAsUpIndicator(R.drawable.ic_menu);

        drawerLayout = findViewById(R.id.drawer_layout);

        NavigationView navigationView = findViewById(R.id.nav_view);

        navigationView.setNavigationItemSelectedListener(this);

                navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                menuItem.setChecked(true);

                Toast.makeText(getApplicationContext(),"Item selected " + Integer.toString(menuItem.getItemId()),Toast.LENGTH_LONG).show();

                switch (menuItem.getItemId())
                {
                    case R.id.redeem:{
                        Intent i = new Intent(getApplicationContext(),Products_Archive.class);

                        startActivity(i);

                        break;
                    }

                    default:
                        Toast.makeText(getApplicationContext(),"Invalid Choice",Toast.LENGTH_SHORT).show();
                }

                drawerLayout.closeDrawers();

                return true;
            }
        });



        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View view, float v) {

            }

            @Override
            public void onDrawerOpened(@NonNull View view) {

            }

            @Override
            public void onDrawerClosed(@NonNull View view) {

            }

            @Override
            public void onDrawerStateChanged(int i) {

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        //Toast.makeText(getApplicationContext(),"Item selected " + Integer.toString(item.getItemId()),Toast.LENGTH_LONG).show();


        switch (item.getItemId()) {
            case android.R.id.home: {
                drawerLayout.openDrawer(GravityCompat.START);
                break;
            }

            case R.id.redeem : {
                Intent i = new Intent(getApplicationContext(),Products_Archive.class);

                startActivity(i);

                break;
            }

            default:
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        Toast.makeText(getApplicationContext(),"Item selected " + Integer.toString(menuItem.getItemId()),Toast.LENGTH_LONG).show();
        int id = menuItem.getItemId();

        switch (id)
        {
            case R.id.redeem : {
                Toast.makeText(getApplicationContext(),"Selected Redeem",Toast.LENGTH_LONG).show();

                Intent i = new Intent(getApplicationContext(),Products_Archive.class);

                startActivity(i);
            }

            default:{
                Toast.makeText(getApplicationContext(),"No Items selected",Toast.LENGTH_LONG).show();
            }
        }

        return true;
    }
}
