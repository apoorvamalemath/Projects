package com.example.abhishek.sihproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class VehicleDetailsForm extends AppCompatActivity {

    EditText edtNum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_details_form);

        edtNum = (EditText)findViewById(R.id.edVehicle);

        

    }
}
