package com.example.abhishek.sihproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatAutoCompleteTextView;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;

public class VehicleDetail2 extends AppCompatActivity {

    private AppCompatAutoCompleteTextView manuDet, modelDet;

    String manu;

    ArrayAdapter<String> adapterVd;

    Button btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_detail2);

        Intent i = getIntent();

        manu = i.getStringExtra("manu");

        String[] models = i.getStringArrayExtra("models");

        btnNext = (Button)findViewById(R.id.btnVDNext);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(), WorkLocation.class);

                startActivity(i);

            }
        });


        manuDet = (AppCompatAutoCompleteTextView)findViewById(R.id.form2md);

        modelDet = (AppCompatAutoCompleteTextView)findViewById(R.id.form2vd);

        manuDet.setThreshold(1);
        manuDet.setText(manu);


        adapterVd = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, models);

        modelDet.setThreshold(1);
        modelDet.setAdapter(adapterVd);


    }
}
