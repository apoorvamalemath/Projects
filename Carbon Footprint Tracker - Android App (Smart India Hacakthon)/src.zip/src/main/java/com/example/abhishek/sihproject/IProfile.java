package com.example.abhishek.sihproject;

public interface IProfile {

    void onImageSelected(int resource);

}
