package com.example.abhishek.sihproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatAutoCompleteTextView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class VehicleDetailForm extends AppCompatActivity {

    private AppCompatAutoCompleteTextView autoTextView, autoTextView2;

    ArrayAdapter<String> adapter1;

    ArrayAdapter<String> adapter;

    String companies[];

    Button btnNext;

    Button btnAdd;

    String em, man, mod;

    int vho = 1;

    ProgressDialog progress;

    private final String TAG = "VehicleDetails";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_vehicle_detail_form);

        progress =  new ProgressDialog(this);

        progress.setTitle("Loading");
        progress.setMessage("Verifying details...");
        progress.setCancelable(false);
        progress.setCanceledOnTouchOutside(true);

        Intent i = getIntent();
        companies = i.getStringArrayExtra("manufacturer");

        em = i.getStringExtra("email");


        btnNext = (Button) findViewById(R.id.btnVDNext);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!autoTextView.getText().toString().isEmpty() && !autoTextView2.getText().toString().isEmpty())
                {
                    new UpdateUserVehicleDetails().execute("");
                }

                progress.show();

                Intent i = new Intent(getApplicationContext(), WorkLocation.class);

                i.putExtra("email",em);

                startActivity(i);
            }
        });

        btnAdd = (Button)findViewById(R.id.AddVeh);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!autoTextView.getText().toString().isEmpty() && !autoTextView2.getText().toString().isEmpty())
                {
                    progress.show();

                    mod = autoTextView2.getText().toString();

                    new UpdateUserVehicleDetails().execute("");

                }
            }
        });

        autoTextView = (AppCompatAutoCompleteTextView) findViewById(R.id.autoTextView);

        autoTextView2 = (AppCompatAutoCompleteTextView) findViewById(R.id.autoTextView2);


        adapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, companies);

        autoTextView.setThreshold(1);
        autoTextView.setAdapter(adapter);



        autoTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Toast.makeText(getApplicationContext(), "Selected One..." + autoTextView.getText().toString(), Toast.LENGTH_LONG).show();

                String manu = autoTextView.getText().toString();

                String newManu = manu;

                man = manu;

                new GetModelDetails().execute(newManu);
            }
        });


        autoTextView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Good", Toast.LENGTH_LONG).show();
            }
        });


    }


    class GetModelDetails extends AsyncTask<String, Void, String> {

        protected String doInBackground(String... params) {
            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;

            String yoururl = "3.94.184.247/model.php";

            String manu = params[0];

            try {

                String url = "http://" + yoururl;

                ArrayList<NameValuePair> valuePairs = new ArrayList<NameValuePair>();
                valuePairs.add(new BasicNameValuePair("manufacturer", manu));

                DefaultHttpClient httpClient = new DefaultHttpClient();

                String paramString = URLEncodedUtils.format(valuePairs, "utf-8");
                url += "?" + paramString;


                HttpGet httpGet = new HttpGet(url);

                HttpResponse httpResponse = httpClient.execute(httpGet);
                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e("Reponse", "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 200);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    Log.e("Line", line);
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                Log.e("json", json);

                Log.e("Action", "Success");

            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "ERROR", Toast.LENGTH_SHORT).show();
            }
            return json;
        }


        @Override
        protected void onPostExecute(String result) {

            try {

                JSONArray array = new JSONArray(result);

                String[] models = new String[array.length()];

                if (result != null) {

                    Toast.makeText(getApplicationContext(), "Result not null in Modelssss", Toast.LENGTH_LONG).show();

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);

                        models[i] = object.getString("vehiclemodel");

                    }

                    Toast.makeText(getApplicationContext(), models.toString(), Toast.LENGTH_LONG).show();


                    adapter1 = new ArrayAdapter<String>(VehicleDetailForm.this, android.R.layout.select_dialog_item, models);


                    autoTextView2.setThreshold(1);
                    autoTextView2.setAdapter(adapter1);

                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "ERROR", Toast.LENGTH_SHORT).show();
            }

        }
    }

        class UpdateUserVehicleDetails extends AsyncTask<String, Void, JSONObject> {

            protected JSONObject doInBackground(String... params) {

                InputStream is = null;
                String error = "";
                String json = "";
                JSONObject jObj = null;

                String yoururl = "3.94.184.247/vehicleinfo.php";


                try {

                    String url = "http://" + yoururl;
                    ArrayList<NameValuePair> valuePairs = new ArrayList<NameValuePair>();
                    valuePairs.add(new BasicNameValuePair("emailid", em));
                    valuePairs.add(new BasicNameValuePair("vhno", Integer.toString(vho)));
                    valuePairs.add(new BasicNameValuePair("manufacturer", man));
                    valuePairs.add(new BasicNameValuePair("vehiclemodel", mod));


                    DefaultHttpClient httpClient = new DefaultHttpClient();
                    String paramString = URLEncodedUtils.format(valuePairs, "utf-8");
                    url += "?" + paramString;
                    HttpGet httpGet = new HttpGet(url);

                    HttpResponse httpResponse = httpClient.execute(httpGet);
                    HttpEntity httpEntity = httpResponse.getEntity();
                    Log.e("Response", "Response " + httpResponse.getStatusLine().getStatusCode());
                    is = httpEntity.getContent();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(
                            is, "iso-8859-1"), 100);
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    is.close();
                    json = sb.toString();
                    Log.e("json", json);
                    jObj = new JSONObject(json);
                    jObj.put("error_code", error);

                    Toast.makeText(getApplicationContext(), "Register Success", Toast.LENGTH_SHORT).show();

                    Log.e("Action", "Success");


                } catch (Exception e) {
                    Log.e(TAG, "Error result " + e.toString());
                }


                return jObj;


            }

            @Override
            protected void onPostExecute(JSONObject result) {

                try {
                    if (result != null) {

                        Log.e("Result", "Result " + result);
                        Toast.makeText(getApplicationContext(), "Result not null", Toast.LENGTH_LONG).show();

                        if (!result.isNull("message")) {

                            String message = result.getString("message");

                            if (message.equals("success")) {


                            } else if (message.equals("fail")) {
                                Toast.makeText(getApplicationContext(), "Oops! There was an error.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Failed", Toast.LENGTH_SHORT).show();
                        Log.e("Error", "Unable to retrieve any data from server");
                    }

                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), "Failed to send data", Toast.LENGTH_SHORT).show();
                    Log.e("Exception", "Exception=" + Log.getStackTraceString(e));
                }

                vho++;

                autoTextView.setText("");
                autoTextView2.setText("");

                Toast.makeText(getApplicationContext(), "Vehicle details added successfully", Toast.LENGTH_SHORT).show();

                progress.dismiss();
            }

        }

    }


