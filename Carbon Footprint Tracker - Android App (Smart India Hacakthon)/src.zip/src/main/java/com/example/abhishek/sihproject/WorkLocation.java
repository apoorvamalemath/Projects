package com.example.abhishek.sihproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.compat.Place;
import com.google.android.libraries.places.compat.ui.PlaceAutocomplete;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class WorkLocation extends AppCompatActivity {

    private int PLACE_AUTOCOMPLETE_REQUEST_CODE = 1;
    private EditText editTextSource, editTextDestination;
    private String TAG = "CreateRide";

    int flag = 0;

    String homeLoc, workLoc;


    TimePicker timePicker1 ;
    TimePicker timePicker2 ;

    String goingTime, leavingTime;

    String userEmail;

    Button btnFinish;

    ProgressDialog progress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_location);

        Intent i = getIntent();

        userEmail = i.getStringExtra("email");

        btnFinish = (Button)findViewById(R.id.Finish);

        timePicker1 = (TimePicker)findViewById(R.id.simpleTimePicker);

        timePicker2 = (TimePicker)findViewById(R.id.simpleTimePicker2);

        progress = new ProgressDialog(this);

        progress.setTitle("Loading");
        progress.setMessage("Verifying details...");
        progress.setCancelable(false); // disable dismiss by tapping outside of the dialog
        progress.setCanceledOnTouchOutside(true);

        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progress.show();

                Intent i = new Intent(getApplicationContext(),Hoomescreen.class);

                startActivity(i);

                //new UpdateUserWorkDetails().execute("");


            }
        });

        // Handle editTextSource Click Handler
        editTextSource = (EditText)findViewById(R.id.editText_Source);

        editTextDestination = (EditText)findViewById(R.id.editText_Destination);

        editTextSource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN).build(WorkLocation.this);
                    startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
                } catch (GooglePlayServicesRepairableException e) {
                    // TODO: Handle the error.
                } catch (GooglePlayServicesNotAvailableException e) {
                    // TODO: Handle the error.
                }
            }
        });

        editTextDestination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = null;
                try {
                    intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN).build(WorkLocation.this);

                    startActivityForResult(intent,PLACE_AUTOCOMPLETE_REQUEST_CODE);

                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }
            }
        });

        timePicker1.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int i, int i1) {

                //Toast.makeText(getApplicationContext(),"Selected " + Integer.toString(i) + " " + Integer.toString(i1),Toast.LENGTH_LONG).show();

                goingTime = Integer.toString(i) + ":" + Integer.toString(i1);

            }
        });
         timePicker2.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int i, int i1) {

                //Toast.makeText(getApplicationContext(),"Selected " + Integer.toString(i) + " " + Integer.toString(i1),Toast.LENGTH_LONG).show();

                leavingTime = Integer.toString(i) + ":" + Integer.toString(i1);

            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {

                Place place = PlaceAutocomplete.getPlace(this, data);

                if(flag == 0)
                {
                    editTextSource.setText(place.getName());
                }

                if(flag == 1)
                {
                    editTextDestination.setText(place.getName());
                }

                flag++;

                Log.i(TAG, "Place: " + place.getName());
            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(this, data);
                // TODO: Handle the error.
                Log.i(TAG, status.getStatusMessage());

            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }

    class UpdateUserWorkDetails extends AsyncTask<String, Void, JSONObject> {

        protected JSONObject doInBackground(String... params) {

            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;

            String yoururl = "3.94.184.247/frequent.php";


            try {

                String url = "http://" + yoururl;
                ArrayList<NameValuePair> valuePairs = new ArrayList<NameValuePair>();
                valuePairs.add(new BasicNameValuePair("email", userEmail));
                valuePairs.add(new BasicNameValuePair("home", homeLoc));
                valuePairs.add(new BasicNameValuePair("work", workLoc));
                valuePairs.add(new BasicNameValuePair("htime", goingTime));
                valuePairs.add(new BasicNameValuePair("wtime", leavingTime));


                DefaultHttpClient httpClient = new DefaultHttpClient();
                String paramString = URLEncodedUtils.format(valuePairs, "utf-8");
                url += "?" + paramString;
                HttpGet httpGet = new HttpGet(url);

                HttpResponse httpResponse = httpClient.execute(httpGet);
                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e("Response", "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 100);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                Log.e("json", json);
                jObj = new JSONObject(json);
                jObj.put("error_code", error);

                Toast.makeText(getApplicationContext(), "Register Success", Toast.LENGTH_SHORT).show();

                Log.e("Action", "Success");


            } catch (Exception e) {
                //Log.e(TAG, "Error result " + e.toString());
            }


            return jObj;


        }

        @Override
        protected void onPostExecute(JSONObject result) {

            try {
                if (result != null) {
                    Log.e("Result", "Result " + result);
                    Toast.makeText(getApplicationContext(), "Result not null", Toast.LENGTH_LONG).show();

                    if (!result.isNull("message")) {

                        String message = result.getString("message");
                        if (message.equals("success")) {

                            Toast.makeText(getApplicationContext(), "Details stored successfully", Toast.LENGTH_SHORT).show();

                            Intent i = new Intent(getApplicationContext(),Hoomescreen.class);

                            startActivity(i);

                        } else if (message.equals("fail")) {
                            Toast.makeText(getApplicationContext(), "Oops! There was an error.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Failed", Toast.LENGTH_SHORT).show();
                    Log.e("Error", "Unable to retrieve any data from server");
                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Failed to send data", Toast.LENGTH_SHORT).show();
                Log.e("Exception", "Exception=" + Log.getStackTraceString(e));
            }
        }

    }
}
