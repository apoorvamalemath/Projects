package com.example.abhishek.sihproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.abhishek.sihproject.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthEmailException;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.BatchUpdateException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.net.ssl.HttpsURLConnection;

public class SignUp extends AppCompatActivity {

    EditText edFname, edLname,gmail, PhNo,OTP, pwd,cpwd, referralcode;

    Button verify, next, verifyRef;

    int otp;

    String nm,fnm,em,pd,cpd,ph;

    Boolean verified = false;

    Intent i ;

    String[] companies;

    ProgressDialog progress;

    private static final String TAG = "RegisterActivity";

    private FirebaseFirestore mDb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_sign_up);

        progress = new ProgressDialog(this);

        progress.setTitle("Loading");
        progress.setMessage("Verifying details...");
        progress.setCancelable(false); // disable dismiss by tapping outside of the dialog
        progress.setCanceledOnTouchOutside(true);

        edFname = (EditText)findViewById(R.id.edfname);
        edLname = (EditText)findViewById(R.id.edlname);
        gmail = (EditText)findViewById(R.id.edEmail);

        PhNo = (EditText)findViewById(R.id.edPhNo);
        OTP = (EditText)findViewById(R.id.edOTP);

        pwd = (EditText)findViewById(R.id.edPassword);
        cpwd = (EditText)findViewById(R.id.edCPassword);

        referralcode = (EditText)findViewById(R.id.ReferralCode);

        verify = (Button)findViewById(R.id.btnVerify);

        next = (Button)findViewById(R.id.btnNext);

        verifyRef = (Button)findViewById(R.id.VerifyRef);

        verifyRef.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progress.show();

                new VerifyReferralCode().execute("");
            }
        });
        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progress.show();

                boolean checkNo = isValidMobile(PhNo.getText().toString());

                if(checkNo) {
                    /*OTP.setVisibility(View.VISIBLE);*/
                    OTP.setEnabled(true);
                    try {
                        new SendPostRequest().execute();

                        //OTP.setEnabled(false);

                        verify.setEnabled(false);

                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }else
                {
                    Toast.makeText(getApplicationContext(),"Invalid Mobile Number", Toast.LENGTH_LONG).show();
                }

            }
        });


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progress.show();

                nm = edFname.getText().toString();
                fnm = edLname.getText().toString();
                em = gmail.getText().toString();
                pd = pwd.getText().toString();
                cpd = cpwd.getText().toString();
                ph = PhNo.getText().toString();


                if(!nm.isEmpty() && !fnm.isEmpty() && !em.isEmpty() && !pd.isEmpty() && !cpd.isEmpty() && !ph.isEmpty())
                {
                    if(OTP.getText().toString().equals(Integer.toString(otp)))
                    {
                        verified = true;

                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"OTP Entered is Incorrect. Try Again with new OTP",Toast.LENGTH_LONG).show();
                    }

                    if(verified) {

                          progress.show();

                          registerNewEmail(em,pd);

                          new Register().execute(nm,fnm,em,ph,pd);

                       // new CheckIfExists().execute(ph);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Please Confirm the Mobile using OTP",Toast.LENGTH_LONG).show();

                    }


                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Fields cannot be empty",Toast.LENGTH_LONG).show();
                }




            }
        });


        mDb = FirebaseFirestore.getInstance();

        hideSoftKeyboard();

    }

    private boolean isValidMobile(String phone) {
        return android.util.Patterns.PHONE.matcher(phone).matches();
    }

    public class SendPostRequest extends AsyncTask<String, Void, String> {

        protected void onPreExecute(){}

        protected String doInBackground(String... arg0) {

            try {

                //URL url = new URL("https://studytutorial.in/post.php"); // here is your URL path
                Random r = new Random();

                otp = r.nextInt(9000)+1000;

                String phoneno = PhNo.getText().toString();

                URL url = new URL("http://control.msg91.com/api/sendotp.php?otp_length=4&authkey=218130AquJ4fQ7Q5b0fc093&message=Your verification code is  "+otp+"&sender=OTPSMS&mobile=+91"+phoneno+"&otp="+otp+"&otp_expiry=2"); // here is your URL path
                // URL url = new URL("http://control.msg91.com/api/sendotp.php?otp_length=4&authkey=218130AquJ4fQ7Q5b0fc093&message=Your verification code is  "+otp+"&sender=KLE-TECH&mobile=+91"+phoneno+"&otp="+otp+"&otp_expiry=2"); // here is your URL path

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("name", "abc");
                postDataParams.put("email", "abc@gmail.com");
                Log.e("params",postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000 /* milliseconds */);
                conn.setConnectTimeout(15000 /* milliseconds */);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));
                writer.flush();
                writer.close();
                os.close();

                int responseCode=conn.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in=new BufferedReader(new
                            InputStreamReader(
                            conn.getInputStream()));
                    StringBuffer sb = new StringBuffer("");
                    String line="";

                    while((line = in.readLine()) != null) {

                        sb.append(line);
                        break;
                    }

                    in.close();
                    return sb.toString();

                }
                else {
                    return new String("false : "+responseCode);
                }
            }
            catch(Exception e){
                Log.e("Exception",e.toString());
                return new String("Exception in sendpost request: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getApplicationContext(),result,
                    Toast.LENGTH_LONG).show();
        }
    }

    public String getPostDataString(JSONObject params) throws Exception {

        StringBuilder result = new StringBuilder();
        boolean first = true;

        Iterator<String> itr = params.keys();

        while(itr.hasNext()){

            String key= itr.next();
            Object value = params.get(key);

            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(key, "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(value.toString(), "UTF-8"));

        }
        return result.toString();
    }

    class CheckIfExists extends AsyncTask<String, Void, JSONObject> {

        protected JSONObject doInBackground(String... params) {


            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;


            //String yoururl = "192.168.43.126/userregister.php";
            //String yoururl = "192.168.43.126/checkIfExists.php";
            //String yoururl = "10.2.0.71/checkIfExists.php";
            String yoururl = "210.212.192.29/checkIfExists.php";
            //String yoururl = "10.2.0.171/checkIfExists.php";
            String otp = params[0];





            try {

                String url = "http://" + yoururl;
                ArrayList<NameValuePair> valuePairs = new ArrayList<NameValuePair>();

                valuePairs.add(new BasicNameValuePair("mobile",ph));

                DefaultHttpClient httpClient = new DefaultHttpClient();
                String paramString = URLEncodedUtils.format(valuePairs, "utf-8");
                url += "?" + paramString;
                HttpGet httpGet = new HttpGet(url);

                HttpResponse httpResponse = httpClient.execute(httpGet);
                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e("Response", "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 100);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                Log.e("Output", json);
                jObj = new JSONObject(json);
                jObj.put("error_code", error);

                Toast.makeText(getApplicationContext(), "Register Success", Toast.LENGTH_SHORT).show();

                Log.e("Action", "Success");


            } catch (Exception e) {
                //Log.e(TAG, "Error result " + e.toString());
            }


            return jObj;


        }

        @Override
        protected void onPostExecute(JSONObject result) {

            try {
                if (result != null) {
                    Log.e("Result", "Result " + result);
                    if (!result.isNull("message")) {
                        String message = result.getString("message");
                        if (message.equals("exist")) {

                            Toast.makeText(getApplicationContext(), "Number already exits", Toast.LENGTH_SHORT).show();
                        }  else if (message.equals("nexist")) {

                            new Register().execute(nm,ph,pd);

                        }
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Failed", Toast.LENGTH_SHORT).show();
                    Log.e("Error", "Unable to retrieve any data from server");
                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Failed to send data", Toast.LENGTH_SHORT).show();
                Log.e("Exception", "Exception=" + Log.getStackTraceString(e));
            }
        }

    }

    class Register extends AsyncTask<String, Void, JSONObject> {

        protected JSONObject doInBackground(String... params) {

            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;


            //String yoururl = "192.168.43.126/userregister.php";
            //String yoururl = "192.168.43.126/userregisterAlter.php";
            //String yoururl = "10.2.0.71:80/userregisterAlter.php";
            String yoururl = "3.94.184.247/register.php";
            //String yoururl = "10.2.0.171/userregisterAlter.php";



            String sname = params[0];
            String lname = params[1];
            String email = params[2];
            String phone = params[3];
            String password = params[4];



            try {

                String url = "http://" + yoururl;
                ArrayList<NameValuePair> valuePairs = new ArrayList<NameValuePair>();
                valuePairs.add(new BasicNameValuePair("fname", nm));
                valuePairs.add(new BasicNameValuePair("lname", fnm));
                valuePairs.add(new BasicNameValuePair("email", em));
                valuePairs.add(new BasicNameValuePair("phone", ph));
                valuePairs.add(new BasicNameValuePair("password",pd));
                valuePairs.add(new BasicNameValuePair("fref",referralcode.getText().toString()));

                DefaultHttpClient httpClient = new DefaultHttpClient();
                String paramString = URLEncodedUtils.format(valuePairs, "utf-8");
                url += "?" + paramString;
                HttpGet httpGet = new HttpGet(url);

                HttpResponse httpResponse = httpClient.execute(httpGet);
                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e("Response", "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 100);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                Log.e("json", json);
                jObj = new JSONObject(json);
                jObj.put("error_code", error);

                Toast.makeText(getApplicationContext(), "Register Success", Toast.LENGTH_SHORT).show();

                Log.e("Action", "Success");


            } catch (Exception e) {
                //Log.e(TAG, "Error result " + e.toString());
            }


            return jObj;


        }

        @Override
        protected void onPostExecute(JSONObject result) {

            try {
                if (result != null) {
                    Log.e("Result", "Result " + result);
                    Toast.makeText(getApplicationContext(),"Result not null",Toast.LENGTH_LONG).show();

                    if (!result.isNull("message")) {

                        String message = result.getString("message");
                        if (message.equals("success")) {

                            Toast.makeText(getApplicationContext(), "Register Success", Toast.LENGTH_SHORT).show();

                            new GetManufacturerDetails().execute();

                        }  else if (message.equals("fail")) {
                            Toast.makeText(getApplicationContext(), "Oops! There was an error registering you.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Failed", Toast.LENGTH_SHORT).show();
                    Log.e("Error", "Unable to retrieve any data from server");
                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Failed to send data", Toast.LENGTH_SHORT).show();
                Log.e("Exception", "Exception=" + Log.getStackTraceString(e));
            }
        }

    }

    class GetManufacturerDetails extends AsyncTask<Void, Void, String> {

        protected String doInBackground(Void... params) {
            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;

            String yoururl = "3.94.184.247/company.php";

            try {

                String url = "http://" + yoururl;

                DefaultHttpClient httpClient = new DefaultHttpClient();

                HttpGet httpGet = new HttpGet(url);

                HttpResponse httpResponse = httpClient.execute(httpGet);
                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e("Reponse", "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 200);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    Log.e("Line", line);
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                Log.e("json", json);

                Log.e("Action", "Success");

            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "ERROR", Toast.LENGTH_SHORT).show();
            }
            return json;
        }


        @Override
        protected void onPostExecute(String result) {

            try {

                JSONArray array = new JSONArray(result);

                companies = new String[array.length()];

                if (result != null) {

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);

                        companies[i] = object.getString("manufacturer");

                    }


                    i = new Intent(getApplicationContext(), VehicleDetailForm.class);


                    i.putExtra("manufacturer",companies);
                    i.putExtra("email",gmail.getText().toString());

                    startActivity(i);


                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "ERROR", Toast.LENGTH_SHORT).show();
            }

        }


    }

    class GetModelsDetails extends AsyncTask<Void, Void, String> {

        protected String doInBackground(Void... params) {
            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;

            String yoururl = "3.94.184.247/model.php";

            try {

                String url = "http://" + yoururl;

                DefaultHttpClient httpClient = new DefaultHttpClient();

                HttpGet httpGet = new HttpGet(url);

                HttpResponse httpResponse = httpClient.execute(httpGet);
                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e("Reponse", "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 200);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    Log.e("Line", line);
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                Log.e("json", json);

                Log.e("Action", "Success");

            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "ERROR", Toast.LENGTH_SHORT).show();
            }
            return json;
        }


        @Override
        protected void onPostExecute(String result) {

            try {

                JSONArray array = new JSONArray(result);

                String[] models = new String[array.length()];

                if (result != null) {

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);

                        models[i] = object.getString("manufacturer");

                    }

                    i.putExtra("vehicle",models);

                    startActivity(i);

                    Toast.makeText(getApplicationContext(),companies.toString(),Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "ERROR", Toast.LENGTH_SHORT).show();
            }

        }


    }

    class VerifyReferralCode extends AsyncTask<String, Void, JSONObject> {

        protected JSONObject doInBackground(String... params) {


            InputStream is = null;
            String error = "";
            String json = "";
            JSONObject jObj = null;

            String yoururl = "3.94.184.247/verifyreferal.php";

            try {

                String url = "http://" + yoururl;
                ArrayList<NameValuePair> valuePairs = new ArrayList<NameValuePair>();

                valuePairs.add(new BasicNameValuePair("refcode",referralcode.getText().toString()));

                DefaultHttpClient httpClient = new DefaultHttpClient();

                String paramString = URLEncodedUtils.format(valuePairs, "utf-8");
                url += "?"+paramString;

                HttpGet httpGet = new HttpGet(url);

                HttpResponse httpResponse = httpClient.execute(httpGet);

                HttpEntity httpEntity = httpResponse.getEntity();
                Log.e("Response", "Response " + httpResponse.getStatusLine().getStatusCode());
                is = httpEntity.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 100);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                Log.e("json", json);
                jObj = new JSONObject(json);
                jObj.put("error_code", error);

                Log.e("Action", "Success");



            } catch (Exception e) {
                //Log.e(TAG, "Error result " + e.toString());
            }

            return jObj;


        }
        @Override
        protected void onPostExecute(JSONObject result) {
            try {
                if (result != null) {

                    Log.e("Result", "Result " + result);

                    String message = result.getString("message");

                    if (message.equals("success"))
                    {
                        Toast.makeText(getApplicationContext(),"Referral Code applied successfully" + message , Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Invalid Referral Code", Toast.LENGTH_SHORT).show();
                    }

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Error Occurred ", Toast.LENGTH_SHORT).show();

                    Log.e("Unable", "Unable to retrieve any data from server");
                }

                progress.dismiss();

            } catch (JSONException e) {

                Toast.makeText(getApplicationContext(), "Failed to send data", Toast.LENGTH_SHORT).show();
                Log.e("Exception", "Exception=" + Log.getStackTraceString(e));
            }
        }
    }


    private void hideSoftKeyboard(){
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    public void registerNewEmail(final String email, String password){



        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        Toast.makeText(getApplicationContext(),"Came to OnComplete Firebase",Toast.LENGTH_LONG).show();

                        Log.d(TAG, "createUserWithEmail:onComplete:" + task.isSuccessful());

                        if (task.isSuccessful()){
                            Log.d(TAG, "onComplete: AuthState: " + FirebaseAuth.getInstance().getCurrentUser().getUid());

                            //insert some default data
                            User user = new User();
                            user.setEmail(email);
                            user.setUsername(email.substring(0, email.indexOf("@")));
                            user.setUser_id(FirebaseAuth.getInstance().getUid());

                            FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                                    .setTimestampsInSnapshotsEnabled(true)
                                    .build();
                            mDb.setFirestoreSettings(settings);

                            DocumentReference newUserRef = mDb
                                    .collection(getString(R.string.collection_users))
                                    .document(FirebaseAuth.getInstance().getUid());

                            newUserRef.set(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    progress.dismiss();

                                    if(task.isSuccessful()){
                                        //redirectLoginScreen();
                                        //new Register().execute(nm,fnm,em,ph,pd);
                                    }else{
                                        View parentLayout = findViewById(android.R.id.content);
                                        Snackbar.make(parentLayout, "Something went wrong.", Snackbar.LENGTH_SHORT).show();
                                    }
                                }
                            });

                        }
                        else {

                            FirebaseAuthException e = (FirebaseAuthException)task.getException();

                            Toast.makeText(getApplicationContext(),"Failed Registration : " + e.getMessage() , Toast.LENGTH_LONG).show();

                            Log.e("Failed Registration",e.getMessage());

                            View parentLayout = findViewById(android.R.id.content);
                            Snackbar.make(parentLayout, "Something went wrong.", Snackbar.LENGTH_SHORT).show();
                            progress.dismiss();
                        }


                    }
                });
    }


    private void redirectLoginScreen(){
        Log.d(TAG, "redirectLoginScreen: redirecting to login screen.");

        Intent intent = new Intent(getApplicationContext(), Login.class);
        startActivity(intent);
        finish();
    }
}
